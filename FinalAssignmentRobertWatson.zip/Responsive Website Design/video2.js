jQuery(document).ready(function() {
  jQuery('#playvideo').click(function(ev) {
  
  jQuery("#video_played")[0].src += "&autoplay=1";
    ev.preventDefault();
  });
  
  setTimeout(function() {
    jQuery('#playvideo').trigger('click');
  }, 4000);

}); 